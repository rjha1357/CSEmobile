export const API_BASE_URL = 'https://wordpress.betadelivery.com/cse-staging/';
export const API_PATH_URL = 'https://wordpress.betadelivery.com/cse-staging/assets/upload/profile_image/';

